import { of, Observable } from 'rxjs';
import { savedSearchMock } from './mockGetSavedSearch';
import { savedSearchMockCount } from './mockSavedSearchCount';
import { EnvironmentService } from 'src/app/services/environment.service';
import { getEnvironment } from '../environments/environment';


export class MockEnvironmentService {
	constructor(private prod= false) { }

	getEnvironment(): any {
		if (this.prod) {
			return mockProdEnvironment;
		}
		return mockNonProdEnvironment;
	}
}


// Find out what needs to be included in these
const mockNonProdEnvironment = {
	production: false
};

const mockProdEnvironment = {
	production: true
};

// TODO: need to add a post that checks for savedsearchUrl for saved-search.service getSavedSearch() method
export class MockSavedSearchService {
	get(url: string) {

		console.log('in MockSavedSearchHttpClient, url', url);
		if (url.includes(getEnvironment().savedsearchcountsUrl)) {
			return of(savedSearchMockCount.newVehicles);
		}
	}

	accessToken: string;
	plId: any;

	ngOnInit() {
		this.setAccessToken(this.accessToken);
		this.setPlId(this.plId);
	}
	async setAccessToken(accessToken: any) {
		this.accessToken = accessToken;
	}

	async setPlId(plId: any) {
		this.plId = plId;
	}

	getSavedSearch(): Observable<any> {
		if (true)
			return of({ results: savedSearchMock });
		else
			return null;
	}



	getVehicleCount(searchQuery: string) {
		return new Promise((resolve, reject) => {
			resolve(savedSearchMockCount); reject(null);
		});
	}
}