const savedSearchMockCount = { "newVehicles": 4, "totalVehicles": 17 }
export { savedSearchMockCount };