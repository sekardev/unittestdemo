
const savedSearchMock = [
	{
		"_index": "nwsavedsearch",
		"_type": "nwsavedsearch",
		"_id": "PhodR2sBlrXMKQxKQXE8",
		"_score": null,
		"_source": {
			"mode": "none",
			"EmailId": "TEST1Emails@adesa.com",
			"searchText": "?make=acura&exteriorColor=black,white,gray,blue&auctionChannel=all&vehicleType=Car&fuelType=all",
			"site": ".com",
			"dateCreated": 1560360017950,
			"searchParam": [],
			"searchName": "hello",
			"postalCode": "85204",
			"userId": "191B4346-1271-435E-8856-1238DD515AB8",
			"lowerCaseSearchName": "hello",
			"batchAccessGroupList": [
				"1",
				"385",
				"386",
				"259",
				"387",
				"643",
				"388",
				"390",
				"393",
				"394",
				"395",
				"397",
				"398",
				"399",
				"400",
				"406",
				"407",
				"535",
				"408",
				"536",
				"409",
				"537",
				"410",
				"538",
				"411",
				"412",
				"413",
				"414",
				"415",
				"671",
				"416",
				"417",
				"418",
				"420",
				"421",
				"422",
				"424",
				"425",
				"681",
				"426",
				"682",
				"427",
				"428",
				"429",
				"301",
				"686",
				"687",
				"304",
				"305",
				"306",
				"437",
				"439",
				"312",
				"444",
				"573",
				"190",
				"322",
				"323",
				"453",
				"325",
				"202",
				"330",
				"462",
				"465",
				"210",
				"212",
				"214",
				"216",
				"218",
				"620",
				"621",
				"110",
				"253",
				"382",
				"383",
				"639"
			],
			"status": 0
		},
		"sort": [
			1560360017950
		]
	},
	{
		"_index": "nwsavedsearch",
		"_type": "nwsavedsearch",
		"_id": "kypBM2sBsTjwZjjuXMLD",
		"_score": null,
		"_source": {
			"searchName": "aasdf",
			"searchText": "?make=aston%20martin&auctionChannel=runList%2CliveBlock",
			"mode": "none",
			"EmailId": "TEST1Emails@adesa.com",
			"site": ".com",
			"postalCode": "46032",
			"searchParams": "[{\"category\":\"Make\",\"option\":\"Aston Martin\",\"name\":\"make\",\"value\":\"aston martin\",\"ext\":\"\"},{\"category\":\"Auction Channels\",\"option\":\"Runlist/LiveBlock\",\"name\":\"auctionChannel\",\"value\":\"runList,liveBlock\",\"ext\":\"\"}]",
			"userId": "191B4346-1271-435E-8856-1238DD515AB8",
			"batchAccessGroupList": [
				"208",
				"116",
				"350"
			],
			"lowerCaseSearchName": "aasdf",
			"status": 0,
			"dateCreated": 1559933049967
		},
		"sort": [
			1559933049967
		]
	},
	{
		"_index": "nwsavedsearch",
		"_type": "nwsavedsearch",
		"_id": "kypBM2sBsTjwZjjuXMLD",
		"_score": null,
		"_source": {
			"searchName": "aasdf",
			"searchText": "?make=aston%20martin&auctionChannel=runList%2CliveBlock",
			"mode": "none",
			"EmailId": "TEST1Emails@adesa.com",
			"site": ".com",
			"postalCode": "46032",
			"searchParams": "[{\"category\":\"Make\",\"option\":\"Aston Martin\",\"name\":\"make\",\"value\":\"aston martin\",\"ext\":\"\"},{\"category\":\"Auction Channels\",\"option\":\"Runlist/LiveBlock\",\"name\":\"auctionChannel\",\"value\":\"runList,liveBlock\",\"ext\":\"\"}]",
			"userId": "191B4346-1271-435E-8856-1238DD515AB8",
			"batchAccessGroupList": [
				"208",
				"116",
				"350"
			],
			"lowerCaseSearchName": "aasdf",
			"status": 0,
			"dateCreated": 1559933049967
		},
		"sort": [
			1559933049967
		]
	}, {
		"_index": "nwsavedsearch",
		"_type": "nwsavedsearch",
		"_id": "kypBM2sBsTjwZjjuXMLD",
		"_score": null,
		"_source": {
			"searchName": "aasdf",
			"searchText": "?make=aston%20martin&auctionChannel=runList%2CliveBlock",
			"mode": "none",
			"EmailId": "TEST1Emails@adesa.com",
			"site": ".com",
			"postalCode": "46032",
			"searchParams": "[{\"category\":\"Make\",\"option\":\"Aston Martin\",\"name\":\"make\",\"value\":\"aston martin\",\"ext\":\"\"},{\"category\":\"Auction Channels\",\"option\":\"Runlist/LiveBlock\",\"name\":\"auctionChannel\",\"value\":\"runList,liveBlock\",\"ext\":\"\"}]",
			"userId": "191B4346-1271-435E-8856-1238DD515AB8",
			"batchAccessGroupList": [
				"208",
				"116",
				"350"
			],
			"lowerCaseSearchName": "aasdf",
			"status": 0,
			"dateCreated": 1559933049967
		},
		"sort": [
			1559933049967
		]
	}
];

export { savedSearchMock };