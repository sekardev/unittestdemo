import { BrowserModule } from '@angular/platform-browser';
import { NgModule, Injector } from '@angular/core';

import { RouterModule } from '@angular/router';
import { ReactiveFormsModule } from '@angular/forms';
import { HttpClientModule } from '@angular/common/http';
import { CUSTOM_ELEMENTS_SCHEMA, NO_ERRORS_SCHEMA } from '@angular/core';


import { AppComponent } from './app.component';
import { SavedSearchesComponent } from './saved-searches/saved-searches.component';
import { NoSavedSearchesComponent } from './no-saved-searches/no-saved-searches.component';

@NgModule({
  declarations: [
    AppComponent,
    SavedSearchesComponent,
    NoSavedSearchesComponent
  ],
  imports: [
    BrowserModule, ReactiveFormsModule, HttpClientModule
  ],
  schemas: [CUSTOM_ELEMENTS_SCHEMA, NO_ERRORS_SCHEMA],
  bootstrap: [AppComponent ],
  
})
export class AppModule { }



