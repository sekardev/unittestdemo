
import { Injectable } from '@angular/core';
import { HttpClient, HttpParams, HttpHeaders } from '@angular/common/http';
import { EnvironmentService } from './environment.service';
import { Observable, of, observable, Subscriber } from 'rxjs';
//import { access } from 'fs';
import { savedSearchMock } from 'src/mocks/mockGetSavedSearch';
import { savedSearchMockCount } from '../../mocks/mockSavedSearchCount';


@Injectable({
	providedIn: 'root'
})
export class SavedSearchService {

	accessToken: string;
	plId: any;

	constructor(private httpClient: HttpClient, private environmentService: EnvironmentService) {


	}
	ngOnInit() {
		this.setAccessToken();
		this.setPlId();

	}

	// TODO: don't need this isMock variable, can use a flag from environment
	getSavedSearch(): Observable<any> {

		//	this.setAccessToken();
		if (this.environmentService.getEnvironment().production) {
			const apiUrl = `${this.environmentService.getEnvironment().savedsearchUrl}`;
			let code: string = this.plId === '1' ? '.com' : '.ca';
			var request = { countryCode: code };
			const headers = new HttpHeaders({
				'Authorization': ' Bearer ' + `${this.accessToken}`
			});

			return this.httpClient.post<any[]>(apiUrl, JSON.stringify(request), { headers: headers }).pipe();

		}
		else {
			return Observable.create((observer: Subscriber<any>) => {
				observer.next(savedSearchMock);
				observer.complete();
			});
			
		}


	}

	async getVehicleCount(searchQuery) {
		//this.setAccessToken();
		// const apiUrl = `${this.environmentService.getEnvironment().savedsearchcountsUrl}` + searchQuery + '&counts';

		// const result = await this.httpClient.get(apiUrl, {
		// 	headers: {
		// 		'Authorization': ' Bearer ' + `${this.accessToken}`  // + JSON.parse(sessionStorage.getItem('sessionUser')).accessToken
		// 	}
		// })
		// 	.toPromise() as any;

		// return result;
		return new Promise((resolve,reject)=>{
			resolve(savedSearchMockCount), reject(null)
		})
	}

	async setAccessToken() {
		this.accessToken = JSON.parse(sessionStorage.getItem("iam.login")).accessToken;
	}

	async setPlId() {
		this.plId = JSON.parse(sessionStorage.getItem("iam.login")).plId;
	}

}
