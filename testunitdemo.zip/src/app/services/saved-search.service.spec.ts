import { TestBed, getTestBed, inject } from '@angular/core/testing';
import { SavedSearchService } from './saved-search.service';

import { expect, use } from 'chai';
import { HttpClientModule, HttpClient } from '@angular/common/http';
import {HttpClientTestingModule, HttpTestingController} from '@angular/common/http/testing'

import { savedSearchMock } from 'src/mocks/mockGetSavedSearch';
import { savedSearchMockCount } from 'src/mocks/mockSavedSearchCount';
import { MockEnvironmentService, MockSavedSearchService } from 'src/mocks/mockClasses';
import { EnvironmentService } from './environment.service';

describe('SavedSearchService', () => {
	let savedSearchService: SavedSearchService;
	beforeEach(() => {
		TestBed.configureTestingModule({
			providers: [SavedSearchService, EnvironmentService],
			imports: [
			  HttpClientTestingModule
			],
		  });
	}

	);

	// TODO: add post to MockSavedSearchHttpClient for this method
	it('should return saved search results', inject([HttpTestingController, SavedSearchService],
		(httpMock: HttpTestingController, service: SavedSearchService)  => {
			service.getSavedSearch().subscribe((result)=>{
				console.log(result)
				expect(result.length).to.be.equal(savedSearchMock.length);
			});
		}));

		it('should return saved search vehicle count', inject([HttpTestingController, SavedSearchService],
			(httpMock: HttpTestingController, service: SavedSearchService)  => {
				service.getVehicleCount('').then((result)=>{
					console.log(result)
					expect(result["newVehicles"]).to.be.equal(savedSearchMockCount.newVehicles);
				});
			}));
		
	
	
	// it('should validate ng onit',  inject([HttpTestingController, SavedSearchService, EnvironmentService],
	// 	(httpMock: HttpTestingController, service: SavedSearchService, envService : EnvironmentService)  => {
	// 		envService.getEnvironment();
	// 	service.ngOnInit();

	// }));
	


});


