import { EnvironmentService } from "./environment.service";
import { TestBed } from '@angular/core/testing';
import { expect, use } from 'chai';
import { MockEnvironmentService } from 'src/mocks/mockClasses';

describe('Environment Service', () => {
	let envService: EnvironmentService;
	beforeEach(() => {
		TestBed.configureTestingModule({

			providers: [
				EnvironmentService

			]
		});
		envService = TestBed.get(EnvironmentService);

	}

	);

	it('should return env service', async () => {
		const result = envService.getEnvironment();
		let mockuser: MockEnvironmentService = new MockEnvironmentService();
		mockuser.getEnvironment();
		expect(result).to.exist;

	});


	it('should return prod env  service', async () => {
		let serv = new MockEnvironmentService(true);
		const result = serv.getEnvironment();
		let mockuser: MockEnvironmentService = new MockEnvironmentService();
		mockuser.getEnvironment();
		expect(result).to.exist;

	});


});