import { async, ComponentFixture, TestBed, inject } from '@angular/core/testing';
import { expect, use } from 'chai';

import { SavedSearchesComponent } from './saved-searches.component';
import { MockEnvironmentService, MockSavedSearchService, } from 'src/mocks/mockClasses';
import { NoSavedSearchesComponent } from '../no-saved-searches/no-saved-searches.component';
import { EnvironmentService } from 'src/app/services/environment.service';
import { SavedSearchService } from 'src/app/services/saved-search.service';

import { HttpClientTestingModule } from '@angular/common/http/testing';
import { HttpClient } from '@angular/common/http';
import { savedSearchMock } from '../../mocks/mockGetSavedSearch';

describe('SavedSearchComponent', () => {

	let testHostFixture: ComponentFixture<SavedSearchesComponent>;
	let testSavedSearchComponent: SavedSearchesComponent;
	const mockEnvService = new MockEnvironmentService();
	let mockSearchService: MockSavedSearchService;
    let testBedService: SavedSearchService;
    let componentService : SavedSearchService;


	beforeEach(async(async () => {



		TestBed.configureTestingModule({
			declarations: [
				SavedSearchesComponent, NoSavedSearchesComponent
			],
			providers: [
                SavedSearchService, EnvironmentService,
                { provide: HttpClient, useClass: MockSavedSearchService }
            ],
            imports: [
                HttpClientTestingModule

              ],
         })
      
			.compileComponents();
	
		testHostFixture = await TestBed.createComponent(SavedSearchesComponent);
        testSavedSearchComponent = testHostFixture.componentInstance;
        testBedService = TestBed.get(SavedSearchService);
        componentService = testHostFixture.debugElement.injector.get(SavedSearchService);
		await testHostFixture.detectChanges();
	}));


	describe('ngOnInit', () => {


		beforeEach(async(async () => {

			await testSavedSearchComponent.ngOnInit();
		}));

		it('should return component variables', () => {
    
			expect(testSavedSearchComponent.savedSearchList).to.be.exist;
			expect(testSavedSearchComponent.savedSearchRecords).to.be.exist;
			expect(testSavedSearchComponent.IsSaveSearchExist).to.be.exist;

        });
        it('should return 8 values', () => {
    
			expect(testSavedSearchComponent.savedSearchList.length).to.be.equal(8);
        });
      
        it('should return true values', () => {
    
			expect(testSavedSearchComponent.IsSaveSearchExist).to.be.equal(true);
        });
        it('should return true values', () => {
    
            expect(testSavedSearchComponent.savedSearchRecords.length
            ).to.be.equal(savedSearchMock.length);
        });
     
	});

});


