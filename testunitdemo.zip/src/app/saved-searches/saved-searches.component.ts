import { Component, OnInit } from '@angular/core';
import { SavedSearchService } from 'src/app/services/saved-search.service';
import { savedSearchResponse } from 'src/app/domains/savedSearchResponse';
@Component({
  selector: 'app-saved-searches',
  templateUrl: './saved-searches.component.html',
  styleUrls: ['./saved-searches.component.scss']
})
export class SavedSearchesComponent implements OnInit {
	savedSearchRecords: any[] = [];
	savedSearchList: savedSearchResponse[] = [];
	redirectionUrl: string = 'https://test'
	IsSaveSearchExist: boolean = true;


	constructor(private savedSearchService: SavedSearchService) { }
	ngOnInit() {
	//	this.savedSearchService.ngOnInit();
		this.savedSearchService.
			getSavedSearch()
			.subscribe((data: any) => {
				if (data.length <= 0) { this.IsSaveSearchExist = false; }
				let resultsData = data.map(x => {
					return {
						source: x._source
					}
				});
				this.savedSearchRecords = resultsData.map(x => {
					return {

						searchName: x.source.searchName,
						searchText: x.source.searchText

					}
				});
				this.savedSearchRecords.forEach(x => {
					var result = {} as savedSearchResponse;
					result.searchName = x.searchName;
					result.searchText = x.searchText;
					this.savedSearchService.getVehicleCount(x.searchText).then((data) => {
						result.newVehicles =  0;
						result.totalVehicles =  0;
						this.savedSearchList.push(result);
					}).catch((err) => {
						this.handleError(result);
					});

				});
			}, (err) => this.IsSaveSearchExist = false);
	}

	handleError(result: any) {
		result.newVehicles = 0;
		result.totalVehicles = 0;
		this.savedSearchList.push(result);
	}

}
