export function getEnvironment() {
	const hostname = window.location.hostname;
	const settings = JSON.parse(sessionStorage.getItem(`environment-${hostname}`));

	return {
		production: true,
		buyerOa: settings.interfacePath.buyerOa,
		savedsearchUrl: settings.interfacePath.savedsearchUrl,
		savedsearchcountsUrl: settings.interfacePath.savedsearchcountsUrl
	};
	// return {
	// 	production: false,
	// 	buyerOa: 'https://buy.test1.adesa.com/openauction'
	// };
}

/*
 * For easier debugging in development mode, you can import the following file
 * to ignore zone related error stack frames such as `zone.run`, `zoneDelegate.invokeTask`.
 *
 * This import should be commented out in production mode because it will have a negative impact
 * on performance if an error is thrown.
 */
// import 'zone.js/dist/zone-error';  // Included with Angular CLI.
